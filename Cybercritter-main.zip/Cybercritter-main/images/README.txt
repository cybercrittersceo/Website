Put your 4 PNG images here with these exact names:

  news.png         - for the News section (dog at news desk)
  security.png     - for the Security Updates section (dog at server rack)
  guidance.png     - for the Practical Guidance section (dog with tablet)
  Awareness.png    - for the Awareness section (dog on stage)

Then refresh the webpage and the pictures will appear in the circles.
